function [] = Draw_Map_withLine(lon,lat,data,titlestr,output,Levels,colorstr,xlimit)
%draw the absolute value map with the line averaged by latitude

f=figure('color',[1 1 1]);%figure,background
f.Units = 'inches';%unit
f.Position = [1 1 14 5];%[x y width height] for figure position 
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 14 5]);%for printing

%% left map plot,divid the figure into two parts
subplot(1,7,1:6)
    ticknum=size(Levels,2)-1;% number for the color band
    RGB=cbrewer('seq', colorstr,ticknum,'linear');%color bar,'YlOrRd'
    mode='h';%h or v
    colormap(RGB);  
    %m_map library
    m_proj('Equidistant cylindrical','long',[-180 180],'lat',[-59.9 89.9]); %M_PROJ('proj name','property',value,...)
    m_contourf(lon,lat,data,Levels,'linestyle','none');
    m_coast('line','Color', [.5 .5 .5]);% coast only keep outline    
    m_grid('linestyle','--','LineWidth',0.5,'box','on','tickdir','in',...
    'xlabeldir','middle','yticklabels',[-30;0;30;60]);%'yticklabels',[-30;0;30;60]
    set(gcf,'color','w');   % Need to do this otherwise 'print' turns the lakes black
    hold on
    %title
    t=title(titlestr,'fontsize',15);
    pos  = get( t , 'position' );
    pos1 = pos + [0 -0 0];
    set( t , 'position' , pos1 );
    %set(gca,'FontName','Times New Roman','FontSize',20,'LineWidth',0.1);%set gca font size
    %colorbar and rectangle
    rectangle('Position',[-2.9 -1 0.6 1.5],'FaceColor','w','EdgeColor','k','LineWidth',1);
    hh=colorbar('v','position',[0.18 0.15 0.02 0.4],'FontSize',10);
    %set(get(hh,'Title'),'string','Runoff(mm/yr^-^1)');  
    set(hh,'ytick',Levels);%set(hh,'ytick',[0:200:200*ticknum]);  % set ytick of colorbar    
    %set(hh,'tickdir','out');%tick direction
%% right line plot
subplot(1,7,7)
    data_lat=nanmean(data,2);%nanmean average by the 2rd dimension ignoring the nan
    plot(data_lat,lat,'-k','lineWidth',0.5); %x,y, color, marking, thickness
    hold on
    %xlimit=2000;
    axis([0,xlimit,-59.9,89.9])
    %set(gca,'FontName','Times New Roman','FontSize',10,'LineWidth',0.1);%Set the axis font size
    set(gca,'XTick',[0:xlimit/4:xlimit]);
    set(gca,'YTick',[-30:30:60]);
    %set(gca, 'XTickLabel', name); %Set the label
    %legend
    %l=legend('Runoff (mm/yr)','location','NorthEast');
    %l.Units = 'inches';
    %l.Position = [12.28 4.4 0.015 0.05];
    ylabel('Latitude','FontSize',10) %Y-axis coordinate description   
    set (gca,'position',[0.83,0.12,0.12,0.8] );%Fine-tuning the scale of the whole picture

%print out,saveas(gcf, output, 'jpg')--cannot set resolution
print(gcf,strcat(output, '.png'),'-r300','-dpng');
end
