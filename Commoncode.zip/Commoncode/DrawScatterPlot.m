function[fig]=DrawScatterPlot(obs_data,pred_data,pointNum,dataName,datalimit,obslabel,predlabel,id)
%draw Scatter Plot

% %% preparing seting for point density
len = length(obs_data);
% range=datalimit/30;
% pointNum=zeros(len,1);
% %calculate density
% for i = 1:len
%             x=obs_data(i);
%             y=pred_data(i);
%             point = find(obs_data(:)<x+range & obs_data(:)>x-range & pred_data(:)<y+range & pred_data(:)>y-range);
%             pointNum(i)=length(point);
% end
 %%
 
 
%kernal density
% [XMesh,YMesh]=meshgrid(0:1:3000,0:1:3000);
% XYi=[XMesh(:) YMesh(:)];
% F=ksdensity([obs_data,pred_data],XYi);
% ZMesh=zeros(size(XMesh));
% ZMesh(1:length(F))=F;
%% draw scatter with color
fig=scatter(obs_data,pred_data,3,pointNum,'filled');
hold on;
caxis([0 1500])% color range
%set(c,'YTickLabel',{'200','400','800','1000','1200'})%for colorbar ticklabel
%RGB = cbrewer('seq', 'YlGn',10); %for another colormap to replace default
%colormap(RGB(3:8,:));
%retangle with axis
plot([0,datalimit],[datalimit,datalimit],'k');
hold on;
plot([datalimit,datalimit],[0,datalimit],'k');
hold on;

%set labels and tick etc
if(id>=9)
xlabel(obslabel,'FontName','Helvetica','FontSize',10);
end
if(id==1||id==5||id==9)
ylabel(predlabel,'FontName','Helvetica','FontSize',10);
end
%xlim([-4, 0]);
%ylim([-4, 0]);
%xticks([-4 -3 -2 -1 0]);
%xticklabels({'10^-^4','10^-^3','10^-^2','10^-^1','10^0'})
%yticks([-4 -3 -2 -1 0]);
%yticklabels({'10^-^4','10^-^3','10^-^2','10^-^1','10^0'})
% hold on;
% ax = gca;
% ax.XAxis.TickDirection = 'out';
% ax.XAxis.MinorTick       = 'on';
%minortick1=log10((0.01:(0.1-0.01)/10:0.1)/100);
%minortick2=log10((0.1:(1-0.1)/10:1)/100);
%minortick3=log10((1:(10-1)/10:10)/100);
%minortick4=log10((10:(100-10)/10:100)/100);
%ax.XAxis.MinorTickValues = [minortick1(2:10),minortick2(2:10),minortick3(2:10),minortick4(2:10)];
%ax.YAxis.TickDirection = 'out';
%ax.YAxis.MinorTick       = 'on';
%ax.YAxis.MinorTickValues = [minortick1(2:10),minortick2(2:10),minortick3(2:10),minortick4(2:10)];
%hold on;
%removeid=find(obs_data(:)==-Inf);
%pred_data(removeid)=[];
%obs_data(removeid)=[];

%% statistic
%polyfit
%pn=polyfit(obs_data,pred_data,1);
%yy=polyval(pn,obs_data);
%line=plot(logobs_data,yy,'HandleVisibility','off');
%text(logobs_data(size(logobs_data,1))*1.5,yy(size(logobs_data,1))*1.1,['y=',num2str(pn(1)),'*x+',num2str(pn(2))]);
%hold on

%regression fit
mdl = fitlm(obs_data,pred_data)
r2=mdl.Rsquared.Ordinary
lineSlope=double(mdl.Coefficients{2,1})
lineIntercep=double(mdl.Coefficients{1,1})
Pearson=corr(obs_data,pred_data,'type','Pearson')

plot([0,datalimit],[lineIntercep,datalimit*lineSlope+lineIntercep],'.--k');
plot([0,datalimit],[0,datalimit],'-k');
axis([0,datalimit,0,datalimit])

%% text
%text(logobs_data(size(logobs_data,1))*1.5,yy(size(logobs_data,1))*1.1,['y=',num2str(pn(1)),'*x+',num2str(pn(2))]);
% strings={
%     ['N=', num2str(len)];
%     ['R^2=', num2str(roundn(r2,-2))];
%     ['S/I=', num2str(roundn(lineSlope,-2)),'/',num2str(roundn(lineIntercep,-2))];
%      };
 
%annotation('textbox',[0.25*mod(figid,4),1-0.33*(figid/4+1),0.1,0.1],'LineStyle','-','LineWidth',0.05,'String',strings)
%For ET
% text(300,2800,dataName);
% text(2200,1000,['N=', num2str(len)]);
% text(2100,700,['R^2=', num2str(roundn(r2,-2))]);
% text(1800,300,['S/I=', num2str(roundn(lineSlope,-2)),'/',num2str(roundn(lineIntercep,-1))]);
%For SM
text(datalimit/30,datalimit*0.9,dataName);
text(datalimit*0.75,datalimit*0.3,['N=', num2str(len)]);
text(datalimit*0.72,datalimit*0.2,['R^2=', num2str(roundn(r2,-2))]);
text(datalimit*0.63,datalimit*0.1,['S/I=', num2str(roundn(lineSlope,-2)),'/',num2str(roundn(lineIntercep,-1))]);

end

