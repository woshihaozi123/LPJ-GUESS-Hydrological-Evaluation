%Read .out data of LPJ-GUESS
function [data]=ReadTxtData(filename)
lpjalldata = importdata(filename);
data=lpjalldata.data;
end