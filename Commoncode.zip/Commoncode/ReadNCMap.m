function [ET] = ReadNCMap(filename,ETName)
    ncdisp(filename)                  
    ET=double(ncread(filename,ETName));
end