function []=DrawColorbar(obs_data,pred_data,preci_data)
%draw colorbar

% %% preparing seting
% len = length(obs_data);
% range=100;
% pointNum=zeros(len,1);
% %calculate density
% for i = 1:len
%             x=obs_data(i);
%             y=pred_data(i);
%             point = find(obs_data(:)<x+range & obs_data(:)>x-range & pred_data(:)<y+range & pred_data(:)>y-range);
%             pointNum(i)=length(point);
% end

%% draw scatter with color
fig=scatter(obs_data,pred_data,3,preci_data,'filled');
hold on;
caxis([0 1500])% color range
c=colorbar;
set(c,'tickdir','out')  % out
set(c,'YTick',500:500:1500); %colorbar range
%set(c,'YTickLabel',{'-0.6','-0.3','0.0','0.3','0.6'}) %����̶ȸ�ֵ
delete(fig)
axis off;%
set(get(c,'Title'),'string','Precipitation (mm*yr^-^1)');
set(c,'position',get(c,'position')+[-0.045 0 0 -0.005]);

set(gca,'xtick',[],'xticklabel',[])
set(gca,'ytick',[],'yticklabel',[])



end
