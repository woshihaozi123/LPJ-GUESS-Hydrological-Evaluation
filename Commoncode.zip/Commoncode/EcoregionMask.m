
function [eco1,eco2,eco3,eco4,eco5,eco6,eco7,eco8,eco9,eco10,eco11]=EcoregionMask(diff,S1_x,S2_x,S3_x,S4_x,S5_x,S6_x,S7_x,S8_x,S9_x,S10_x,S11_x,S1_y,S2_y,S3_y,S4_y,S5_y,S6_y,S7_y,S8_y,S9_y,S10_y,S11_y)
%% mask

eco1=zeros(size(S1_x,1),1);
eco2=zeros(size(S2_x,1),1);
eco3=zeros(size(S3_x,1),1);
eco4=zeros(size(S4_x,1),1);
eco5=zeros(size(S5_x,1),1);
eco6=zeros(size(S6_x,1),1);
eco7=zeros(size(S7_x,1),1);
eco8=zeros(size(S8_x,1),1);
eco9=zeros(size(S9_x,1),1);
eco10=zeros(size(S10_x,1),1);
eco11=zeros(size(S11_x,1),1);

for i=1:1:size(S1_x,1)
    lpjlat=S1_y(i);
    lpjlon=S1_x(i);
    eco1(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
 
for i=1:1:size(S2_x,1)
    lpjlat=S2_y(i);
    lpjlon=S2_x(i);
    eco2(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
 
for i=1:1:size(S3_x,1)
    lpjlat=S3_y(i);
    lpjlon=S3_x(i);
    eco3(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
 
for i=1:1:size(S4_x,1)
    lpjlat=S4_y(i);
    lpjlon=S4_x(i);
    eco4(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S5_x,1)
    lpjlat=S5_y(i);
    lpjlon=S5_x(i);
    eco5(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S6_x,1)
    lpjlat=S6_y(i);
    lpjlon=S6_x(i);
    eco6(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S7_x,1)
    lpjlat=S7_y(i);
    lpjlon=S7_x(i);
    eco7(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S8_x,1)
    lpjlat=S8_y(i);
    lpjlon=S8_x(i);
    eco8(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S9_x,1)
    lpjlat=S9_y(i);
    lpjlon=S9_x(i);
    eco9(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S10_x,1)
    lpjlat=S10_y(i);
    lpjlon=S10_x(i);
    eco10(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end
for i=1:1:size(S11_x,1)
    lpjlat=S11_y(i);
    lpjlon=S11_x(i);
    eco11(i)=diff(floor((lpjlat-(-90))/0.5)+1,floor((lpjlon-(-180))/0.5)+1);
end     

      
end
