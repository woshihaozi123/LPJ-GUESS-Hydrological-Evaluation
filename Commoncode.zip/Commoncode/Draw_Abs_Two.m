function [] = Draw_Abs_Two(lon,lat,data1,data2,titlestr,output,Levels)
 ticknum=7;
f=figure('color',[1 1 1]);
f.Units = 'inches';
f.Position = [0 0 24 10];%[x y width height] for looking
set(gcf,'PaperUnits','inches','PaperPosition',[0 0 24 10]);%for printing

%left plot
subplot(1,2,1)
    %color bar
    RGB=cbrewer('seq', 'YlOrRd',ticknum,'linear');
    mode='h';
    %colorbarn1(Levels,RGB,mode);% set colormap and colorbar
    colormap(RGB);    
    
    m_proj('Equidistant cylindrical','long',[-180 180],'lat',[-59.9 89.9]); %M_PROJ('proj name','property',value,...)
    m_contourf(lon,lat,data1,Levels,'linestyle','none');
    m_coast('line','Color', [.5 .5 .5]);% ֻ����������    
    m_grid('linestyle','--','LineWidth',0.5,'box','on','tickdir','in',...
    'xlabeldir','middle','yticklabels',[-30;0;30;60]);%'yticklabels',[-30;0;30;60]
    set(gcf,'color','w');   % Need to do this otherwise 'print' turns the lakes black
    hold on
    t=title(titlestr,'fontsize',20);
    pos  = get( t , 'position' );
    pos1 = pos + [0 0.1 0];
    set( t , 'position' , pos1 );
    set(gca,'FontName','Times New Roman','FontSize',10,'LineWidth',0.1);%���������������С
    %Description. caxis( limits ) sets the colormap limits for the current axes. 
    %limits is a two-element vector of the form [cmin cmax] . All values in the colormap indexing array that are less than or equal to cmin map to the first row in the colormap.
    %caxis([-60 60]);
    rectangle('Position',[-2.8 -1 0.7 1.6],'FaceColor','w','EdgeColor','k','LineWidth',1);
    hold on
    hh=colorbar('v','position',[0.160 0.315 0.006 0.23],'FontSize',10);
    set(get(hh,'Title'),'string','ET(mm*yr^-^1)');
    % �޸�colorbar�ļ��
    set(hh,'ytick',[0:200:200*ticknum]);

    

subplot(1,2,2)
        %color bar
    RGB=cbrewer('seq', 'YlOrRd',ticknum,'linear');
    mode='h';
    %colorbarn1(Levels,RGB,mode);% set colormap and colorbar
    colormap(RGB);    
    
    m_proj('Equidistant cylindrical','long',[-180 180],'lat',[-59.9 89.9]); %M_PROJ('proj name','property',value,...)
    m_contourf(lon,lat,data2,Levels,'linestyle','none');
    m_coast('line','Color', [.5 .5 .5]);% ֻ����������    
    m_grid('linestyle','--','LineWidth',0.5,'box','on','tickdir','in',...
    'xlabeldir','middle','yticklabels',[-30;0;30;60]);%'yticklabels',[-30;0;30;60]
    set(gcf,'color','w');   % Need to do this otherwise 'print' turns the lakes black
    hold on
    t=title(titlestr,'fontsize',20);
    pos  = get( t , 'position' );
    pos1 = pos + [0 0.1 0];
    set( t , 'position' , pos1 );
    set(gca,'FontName','Times New Roman','FontSize',10,'LineWidth',0.1);%���������������С
    %Description. caxis( limits ) sets the colormap limits for the current axes. 
    %limits is a two-element vector of the form [cmin cmax] . All values in the colormap indexing array that are less than or equal to cmin map to the first row in the colormap.
    %caxis([-60 60]);
    rectangle('Position',[-2.8 -1 0.7 1.6],'FaceColor','w','EdgeColor','k','LineWidth',1);
    hold on
    hh=colorbar('v','position',[0.600 0.315 0.006 0.23],'FontSize',10);
    set(get(hh,'Title'),'string','ET(mm*yr^-^1)');
    % �޸�colorbar�ļ��
    set(hh,'ytick',[0:200:200*ticknum]);

print(gcf,strcat(output, '.jpg'),'-r600','-djpeg');
end
