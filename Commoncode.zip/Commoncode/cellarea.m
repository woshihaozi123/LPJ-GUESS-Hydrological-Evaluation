function [ area ] = cellarea( varargin )
% grid cell area in m2, a prerequest is that the 
% cells are equal in degrees, eg. 0.5X0.5 degrees.
% change the "single" dlat to dlon if not squares and change
% the number of input parameters.
    if nargin<1
        disp('wrong number of input arguments')
    elseif nargin == 1
        lats = varargin{1};
        res = 0.5;
    elseif nargin == 2
        lats = varargin{1};
        res = varargin{2};
    elseif nargin > 2
        'too many input arguments'
    end
    R = 6371221.3;

    dlat = res  * pi / 180;
    rads = lats * pi / 180;
    area = R^2 * cos(rads) * dlat * sin(dlat/2) * 2;
end

